Setup & Usage
Get your bot token:                              DISCORD / https://discord.gg/MMAgSA9r5g

Create a Discord bot at the Discord Developer Portal, add it to your server with appropriate permissions, and copy the bot token.

Run the bot script:

bash

python leegloo_raideur.py
Enter your Discord bot token when prompted (input is hidden for security).

Once connected, use the interactive terminal menu:

java                                              DISCORD / https://discord.gg/MMAgSA9r5g


Options:
[1] Bot stats
[2] Channel dump (save channels info)
[3] User dump (save members info)
[4] Nuke server (danger!)
[exit] Quit the bot
Enter the option number to perform the corresponding action.

Command Details
[1] Bot stats
Shows the bot's current status and lists servers it is connected to, including member counts.

[2] Channel dump
Saves a list of all channels in a server to a local text file.

[3] User dump
Saves a list of all members in a server to a local text file.

[4] Nuke server
Deletes all channels and roles, bans members, and creates many new channels and roles to "nuke" the server.

Warning: This command is destructive and should only be used on servers you own or have explicit permission to manage.

Important Notes
The bot must be added to the target Discord server to perform any actions there.

Your bot token is sensitive information — keep it secret and do not share it.

Running destructive commands like nuking may violate Discord's Terms of Service or server rules. Use with caution.

The bot requires appropriate permissions on the server to manage channels, roles, bans, etc.

Some operations may be rate-limited by Discord API and take time to complete.

Troubleshooting
If the bot cannot find a guild, make sure it is added to that server and the server ID is correct.

Check that the bot has the necessary permissions for the actions you want to perform.

If commands do not respond, ensure your token is valid and your internet connection is stable.

Contribution
Feel free to fork and contribute to improve the bot!
Please submit issues or pull requests with clear descriptions.

Disclaimer
This bot is provided as-is without warranty. The author is not responsible for any damage caused by misuse. Always test in safe environments.

Author
Created and maintained by Leegloo                       


  DISCORD / https://discord.gg/MMAgSA9r5g

  DISCORD / https://discord.gg/MMAgSA9r5g

  DISCORD / https://discord.gg/MMAgSA9r5g

  DISCORD / https://discord.gg/MMAgSA9r5g

  DISCORD / https://discord.gg/MMAgSA9r5g

  DISCORD / https://discord.gg/MMAgSA9r5g

  DISCORD / https://discord.gg/MMAgSA9r5g

  DISCORD / https://discord.gg/MMAgSA9r5g

